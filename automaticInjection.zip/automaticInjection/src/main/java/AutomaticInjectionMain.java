import com.automatic.bean.Country;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AutomaticInjectionMain {

    public static void main(String arg[]) {
        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("com/automatic/xml/bean.xml");

        Country country = (Country)applicationContext.getBean("venezuela");

        System.out.println(country.toString());
        ((ConfigurableApplicationContext)applicationContext).close();
        System.out.println("Hola");


    }
}
