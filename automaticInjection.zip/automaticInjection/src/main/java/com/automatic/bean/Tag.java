package com.automatic.bean;

import java.util.Properties;

public class Tag {

    private Properties properties;


    public Tag(Properties name) {
        this.properties = name;
    }

    public Tag() {
    }

    public Properties getProperties() {
        return properties;
    }

    public void setProperties(Properties properties) {
        this.properties = properties;
    }

    @Override
    public String toString() {
        return "Tag{" +
                "properties=" + properties +
                '}';
    }
}
