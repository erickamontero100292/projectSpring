package com.bean.scope;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

    public static void main (String args[]){

        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("com.scope.xml/bean.xml");

        Circle circle = (Circle)applicationContext.getBean("circle");
        Circle circle2 = (Circle)applicationContext.getBean("circle");
        Circle circle3 = (Circle)applicationContext.getBean("circlesingleton");
        Circle circle4 = (Circle)applicationContext.getBean("circlesingleton");

        System.out.println(circle.toString());
        System.out.println(circle2.toString());
        System.out.println(circle3.toString());
        System.out.println(circle4.toString());

        ((ConfigurableApplicationContext)applicationContext).close();

    }
}
