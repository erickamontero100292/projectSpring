package com.bean.scope;

public class Circle {

    private float radio;
    private float area;

    public Circle() {
    }

    public Circle(float radio, float area) {
        this.radio = radio;
        this.area = area;
    }

    public float getRadio() {
        return radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }

    public float getArea() {
        return area;
    }

    public void setArea(float area) {
        this.area = area;
    }
}
